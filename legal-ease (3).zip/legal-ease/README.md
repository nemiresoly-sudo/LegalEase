# Legal Ease — AI-Powered Legal Document Generator

A simple browser-based tool that generates common legal documents (NDA, Rental
Agreement, Employment Offer, Freelance Contract) from a form. No build tools
or server required — just open `index.html`.

## Project Structure
```
legal-ease/
├── index.html        # Main page
├── css/
│   └── style.css     # Styling
├── js/
│   ├── templates.js  # Document templates & field definitions
│   └── app.js         # Form rendering + generation logic
└── README.md
```

## Running it
Just open `index.html` in any browser — double-click it, or use VS Code's
"Live Server" extension for auto-reload while editing.

## Extending it
Add a new document type by adding an entry to `DOCUMENT_TYPES` in
`js/templates.js` — no changes needed elsewhere.

---
See the setup guide the assistant provided for step-by-step VS Code instructions.

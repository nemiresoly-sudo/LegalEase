const docTypeSelect = document.getElementById('docType');
const docForm = document.getElementById('docForm');
const generateBtn = document.getElementById('generateBtn');
const preview = document.getElementById('preview');
const downloadBtn = document.getElementById('downloadTxt');
const downloadPdfBtn = document.getElementById('downloadPdf');
const editBtn = document.getElementById('editBtn');
const copyBtn = document.getElementById('copyBtn');

let currentText = '';
let isEditing = false;

function renderForm(typeKey) {
  const config = DOCUMENT_TYPES[typeKey];
  docForm.innerHTML = '';
  config.fields.forEach(field => {
    const wrapper = document.createElement('div');
    const label = document.createElement('label');
    label.textContent = field.label;
    label.setAttribute('for', field.id);

    const input = document.createElement('input');
    input.type = field.type;
    input.id = field.id;
    input.name = field.id;

    wrapper.appendChild(label);
    wrapper.appendChild(input);
    docForm.appendChild(wrapper);
  });
}

function collectData(typeKey) {
  const config = DOCUMENT_TYPES[typeKey];
  const data = {};
  config.fields.forEach(field => {
    const el = document.getElementById(field.id);
    data[field.id] = el.value.trim() || `[${field.label}]`;
  });
  return data;
}

function generateDocument() {
  const typeKey = docTypeSelect.value;
  const config = DOCUMENT_TYPES[typeKey];
  const data = collectData(typeKey);
  currentText = config.build(data);
  isEditing = false;
  editBtn.textContent = 'Edit';
  preview.textContent = currentText;
  downloadBtn.disabled = false;
  downloadPdfBtn.disabled = false;
  editBtn.disabled = false;
  copyBtn.disabled = false;
}

function toggleEdit() {
  if (!isEditing) {
    // Enter edit mode: swap the preview text for an editable textarea
    isEditing = true;
    editBtn.textContent = 'Save Edits';
    const textarea = document.createElement('textarea');
    textarea.id = 'editArea';
    textarea.value = currentText;
    preview.innerHTML = '';
    preview.appendChild(textarea);
    textarea.focus();
  } else {
    // Save mode: pull the edited text back out and re-render as plain preview
    const textarea = document.getElementById('editArea');
    currentText = textarea.value;
    isEditing = false;
    editBtn.textContent = 'Edit';
    preview.textContent = currentText;
  }
}

function downloadPdf() {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF({ unit: 'pt', format: 'a4' });
  const margin = 48;
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const maxWidth = pageWidth - margin * 2;
  const lineHeight = 16;

  doc.setFont('times', 'normal');
  doc.setFontSize(11);

  const lines = doc.splitTextToSize(currentText, maxWidth);
  let y = margin;

  lines.forEach(line => {
    if (y > pageHeight - margin) {
      doc.addPage();
      y = margin;
    }
    doc.text(line, margin, y);
    y += lineHeight;
  });

  doc.save(`${docTypeSelect.value}-document.pdf`);
}

function downloadText() {
  const blob = new Blob([currentText], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${docTypeSelect.value}-document.txt`;
  a.click();
  URL.revokeObjectURL(url);
}

function copyText() {
  navigator.clipboard.writeText(currentText).then(() => {
    copyBtn.textContent = 'Copied!';
    setTimeout(() => (copyBtn.textContent = 'Copy Text'), 1500);
  });
}

docTypeSelect.addEventListener('change', () => renderForm(docTypeSelect.value));
generateBtn.addEventListener('click', generateDocument);
downloadBtn.addEventListener('click', downloadText);
downloadPdfBtn.addEventListener('click', downloadPdf);
editBtn.addEventListener('click', toggleEdit);
copyBtn.addEventListener('click', copyText);

// Initial render
renderForm(docTypeSelect.value);

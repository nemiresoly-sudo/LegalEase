// Field definitions and templates for each document type.
// Add new document types here by following the same pattern.

const DOCUMENT_TYPES = {
  nda: {
    label: "Non-Disclosure Agreement",
    fields: [
      { id: "partyA", label: "Disclosing Party (Name)", type: "text" },
      { id: "partyB", label: "Receiving Party (Name)", type: "text" },
      { id: "effectiveDate", label: "Effective Date", type: "date" },
      { id: "purpose", label: "Purpose of Disclosure", type: "text" },
      { id: "term", label: "Term (in years)", type: "number" },
      { id: "governingLaw", label: "Governing Law (State/Country)", type: "text" }
    ],
    build: (d) => `NON-DISCLOSURE AGREEMENT

This Non-Disclosure Agreement ("Agreement") is entered into as of ${d.effectiveDate} by and between:

${d.partyA} ("Disclosing Party")
and
${d.partyB} ("Receiving Party")

1. PURPOSE
The parties wish to explore ${d.purpose}, and in connection with this purpose, the Disclosing Party may share certain confidential and proprietary information.

2. CONFIDENTIAL INFORMATION
The Receiving Party agrees to hold all confidential information in strict confidence and not to disclose it to any third party without prior written consent.

3. TERM
This Agreement shall remain in effect for a period of ${d.term} year(s) from the Effective Date, unless terminated earlier by mutual written consent.

4. GOVERNING LAW
This Agreement shall be governed by the laws of ${d.governingLaw}.

5. SIGNATURES

_____________________________          _____________________________
${d.partyA} (Disclosing Party)         ${d.partyB} (Receiving Party)

Date: ______________                   Date: ______________`
  },

  rental: {
    label: "Residential Rental Agreement",
    fields: [
      { id: "landlord", label: "Landlord Name", type: "text" },
      { id: "tenant", label: "Tenant Name", type: "text" },
      { id: "property", label: "Property Address", type: "text" },
      { id: "rent", label: "Monthly Rent (amount)", type: "text" },
      { id: "startDate", label: "Lease Start Date", type: "date" },
      { id: "duration", label: "Lease Duration (months)", type: "number" },
      { id: "deposit", label: "Security Deposit (amount)", type: "text" }
    ],
    build: (d) => `RESIDENTIAL RENTAL AGREEMENT

This Rental Agreement is made on ${d.startDate} between:

${d.landlord} ("Landlord")
and
${d.tenant} ("Tenant")

1. PROPERTY
The Landlord agrees to rent to the Tenant the property located at: ${d.property}.

2. TERM
The lease shall begin on ${d.startDate} and continue for ${d.duration} months.

3. RENT
The Tenant agrees to pay monthly rent of ${d.rent}, due on the first day of each month.

4. SECURITY DEPOSIT
The Tenant shall pay a security deposit of ${d.deposit}, refundable subject to the condition of the property at lease end.

5. MAINTENANCE
The Tenant agrees to maintain the property in good condition and report damages promptly.

6. SIGNATURES

_____________________________          _____________________________
${d.landlord} (Landlord)                ${d.tenant} (Tenant)

Date: ______________                   Date: ______________`
  },

  employment: {
    label: "Employment Offer Letter",
    fields: [
      { id: "company", label: "Company Name", type: "text" },
      { id: "employee", label: "Candidate Name", type: "text" },
      { id: "position", label: "Job Title", type: "text" },
      { id: "startDate", label: "Start Date", type: "date" },
      { id: "salary", label: "Annual Salary", type: "text" },
      { id: "manager", label: "Reporting Manager", type: "text" }
    ],
    build: (d) => `EMPLOYMENT OFFER LETTER

Dear ${d.employee},

We are pleased to offer you the position of ${d.position} at ${d.company}. This letter outlines the key terms of your employment.

1. START DATE
Your employment will begin on ${d.startDate}.

2. COMPENSATION
Your annual salary will be ${d.salary}, paid in accordance with our standard payroll schedule.

3. REPORTING
You will report directly to ${d.manager}.

4. AT-WILL EMPLOYMENT
Your employment with ${d.company} is at-will, meaning either party may terminate the relationship at any time, with or without cause or notice, subject to applicable law.

We look forward to welcoming you to the team.

Sincerely,

_____________________________
On behalf of ${d.company}

Acknowledged and Accepted:

_____________________________          Date: ______________
${d.employee}`
  },

  freelance: {
    label: "Freelance / Service Contract",
    fields: [
      { id: "client", label: "Client Name", type: "text" },
      { id: "freelancer", label: "Freelancer Name", type: "text" },
      { id: "serviceDesc", label: "Description of Services", type: "text" },
      { id: "fee", label: "Total Fee / Rate", type: "text" },
      { id: "startDate", label: "Start Date", type: "date" },
      { id: "deadline", label: "Completion Deadline", type: "date" }
    ],
    build: (d) => `FREELANCE SERVICE AGREEMENT

This Agreement is entered into on ${d.startDate} between:

${d.client} ("Client")
and
${d.freelancer} ("Freelancer")

1. SCOPE OF SERVICES
The Freelancer agrees to perform the following services: ${d.serviceDesc}.

2. COMPENSATION
The Client agrees to pay the Freelancer ${d.fee} for the completed services.

3. TIMELINE
Work shall commence on ${d.startDate} and be completed by ${d.deadline}.

4. INDEPENDENT CONTRACTOR STATUS
The Freelancer is an independent contractor and not an employee of the Client. The Freelancer is responsible for their own taxes and insurance.

5. OWNERSHIP
Upon full payment, all work product shall become the property of the Client.

6. SIGNATURES

_____________________________          _____________________________
${d.client} (Client)                    ${d.freelancer} (Freelancer)

Date: ______________                   Date: ______________`
  }
};
